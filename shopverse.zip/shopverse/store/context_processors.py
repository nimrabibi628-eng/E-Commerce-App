from django.conf import settings

from .cart import Cart
from .models import Category


def shop(request):
    return {
        "cart_count": len(Cart(request)),
        "nav_categories": Category.objects.all(),
        "currency": settings.CURRENCY,
    }
