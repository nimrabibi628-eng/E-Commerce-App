from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .models import Order


class BootstrapMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.setdefault("class", "form-control")


class LoginForm(BootstrapMixin, AuthenticationForm):
    pass


class SignupForm(BootstrapMixin, UserCreationForm):
    pass


class CheckoutForm(BootstrapMixin, forms.ModelForm):
    class Meta:
        model = Order
        fields = ["full_name", "phone", "address", "city"]
        widgets = {"address": forms.Textarea(attrs={"rows": 3})}
