from django.core.management.base import BaseCommand
from django.utils.text import slugify

from store.models import Category, Product

DATA = {
    "Electronics": [
        ("Wireless Headphones", 8999, "🎧", "Bluetooth 5.3 headphones with 30 hours of battery life."),
        ("Smart Watch", 12999, "⌚", "Track your steps, sleep and heart rate."),
        ("Power Bank 20000mAh", 4499, "🔋", "Fast charging power bank with two USB ports."),
        ("Gaming Mouse", 3299, "🖱️", "Ergonomic mouse with adjustable DPI and RGB lights."),
    ],
    "Fashion": [
        ("Classic T-Shirt", 1499, "👕", "Soft 100% cotton t-shirt, available in many sizes."),
        ("Running Shoes", 6999, "👟", "Lightweight shoes with extra cushioning."),
        ("Leather Wallet", 2499, "👛", "Slim wallet with six card slots."),
        ("Sunglasses", 1999, "🕶️", "UV400 protection with a durable frame."),
    ],
    "Home": [
        ("Ceramic Mug Set", 1799, "☕", "Set of four mugs, dishwasher safe."),
        ("Desk Lamp", 2999, "💡", "LED lamp with three brightness levels."),
        ("Backpack", 3799, "🎒", "Water resistant backpack with a laptop sleeve."),
        ("Water Bottle", 999, "🧴", "Insulated steel bottle that keeps drinks cold for 24 hours."),
    ],
}


class Command(BaseCommand):
    help = "Load sample categories and products"

    def handle(self, *args, **options):
        count = 0
        for cat_name, products in DATA.items():
            category, _ = Category.objects.get_or_create(name=cat_name, defaults={"slug": slugify(cat_name)})
            for name, price, emoji, desc in products:
                _, created = Product.objects.get_or_create(
                    slug=slugify(name),
                    defaults={"category": category, "name": name, "price": price,
                              "emoji": emoji, "description": desc, "stock": 25},
                )
                count += created
        self.stdout.write(self.style.SUCCESS(f"Added {count} new products."))
