from decimal import Decimal

from .models import Product


class Cart:
    """Session based shopping cart: {product_id: quantity}."""

    KEY = "cart"

    def __init__(self, request):
        self.session = request.session
        self.data = self.session.setdefault(self.KEY, {})

    def _save(self):
        self.session.modified = True

    def add(self, product, quantity=1, override=False):
        pid = str(product.id)
        new_qty = quantity if override else self.data.get(pid, 0) + quantity
        new_qty = min(new_qty, product.stock)
        if new_qty <= 0:
            self.data.pop(pid, None)
        else:
            self.data[pid] = new_qty
        self._save()

    def remove(self, product):
        self.data.pop(str(product.id), None)
        self._save()

    def clear(self):
        self.session[self.KEY] = {}
        self._save()

    def items(self):
        products = Product.objects.filter(id__in=self.data.keys(), is_active=True)
        rows = []
        for p in products:
            qty = self.data[str(p.id)]
            rows.append({"product": p, "quantity": qty, "subtotal": p.price * qty})
        return rows

    def __iter__(self):
        return iter(self.items())

    def __len__(self):
        return sum(self.data.values())

    def total(self):
        return sum((r["subtotal"] for r in self.items()), Decimal("0"))
