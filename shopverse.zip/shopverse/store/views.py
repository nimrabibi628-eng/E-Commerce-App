from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .cart import Cart
from .forms import CheckoutForm, SignupForm
from .models import Order, OrderItem, Product


def _is_ajax(request):
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _to_int(value, default=1):
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return default


def home(request):
    products = Product.objects.filter(is_active=True).select_related("category")
    q = request.GET.get("q", "").strip()
    category = request.GET.get("category", "")
    sort = request.GET.get("sort", "")

    if q:
        products = products.filter(Q(name__icontains=q) | Q(description__icontains=q))
    if category:
        products = products.filter(category__slug=category)
    order = {"price_asc": "price", "price_desc": "-price"}.get(sort, "-created")
    products = products.order_by(order)

    page = Paginator(products, 8).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    return render(request, "store/home.html", {
        "page": page,
        "q": q,
        "active_category": category,
        "sort": sort,
        "querystring": params.urlencode(),
    })


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    related = Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk)[:4]
    return render(request, "store/product_detail.html", {"product": product, "related": related})


def cart_detail(request):
    cart = Cart(request)
    return render(request, "store/cart.html", {"items": cart.items(), "total": cart.total()})


@require_POST
def cart_add(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_active=True)
    cart = Cart(request)
    if product.stock < 1:
        message = f"{product.name} is out of stock"
        if _is_ajax(request):
            return JsonResponse({"ok": False, "message": message, "count": len(cart)}, status=400)
        messages.error(request, message)
        return redirect("product_detail", slug=product.slug)
    cart.add(product, _to_int(request.POST.get("quantity")))
    message = f"{product.name} added to cart"
    if _is_ajax(request):
        return JsonResponse({"ok": True, "message": message, "count": len(cart)})
    messages.success(request, message)
    return redirect("cart")


@require_POST
def cart_update(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    qty = _to_int(request.POST.get("quantity"), 1)
    Cart(request).add(product, qty, override=True)
    return redirect("cart")


@require_POST
def cart_remove(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    Cart(request).remove(product)
    messages.info(request, f"{product.name} removed from cart")
    return redirect("cart")


@login_required
def checkout(request):
    cart = Cart(request)
    items = cart.items()
    if not items:
        messages.warning(request, "Your cart is empty.")
        return redirect("home")

    initial = {"full_name": request.user.get_full_name() or request.user.username}
    form = CheckoutForm(request.POST or None, initial=initial)

    if request.method == "POST" and form.is_valid():
        enough = True
        with transaction.atomic():
            ids = [row["product"].id for row in items]
            locked = {p.id: p for p in Product.objects.select_for_update().filter(id__in=ids)}
            for row in items:
                if locked[row["product"].id].stock < row["quantity"]:
                    enough = False
            if enough:
                order = form.save(commit=False)
                order.user = request.user
                order.total = cart.total()
                order.save()
                for row in items:
                    product = locked[row["product"].id]
                    OrderItem.objects.create(
                        order=order, product=product, name=product.name,
                        price=product.price, quantity=row["quantity"],
                    )
                    product.stock -= row["quantity"]
                    product.save(update_fields=["stock"])
        if not enough:
            messages.error(request, "Some items are no longer available in that quantity. Please review your cart.")
            return redirect("cart")
        cart.clear()
        return redirect("order_success", order_id=order.id)

    return render(request, "store/checkout.html", {"form": form, "items": items, "total": cart.total()})


@login_required
def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    return render(request, "store/order_success.html", {"order": order})


@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "store/orders.html", {"orders": orders})


def signup(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = SignupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Welcome! Your account has been created.")
        return redirect("home")
    return render(request, "registration/signup.html", {"form": form})
