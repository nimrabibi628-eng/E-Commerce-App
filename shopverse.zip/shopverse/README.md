# ShopVerse – Django E-commerce

Run these commands inside this folder:

```
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python manage.py makemigrations store
python manage.py migrate
python manage.py seed          # sample products
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/  (admin panel: /admin/)

Features: product list with search, category filter, sorting and pagination, product detail,
AJAX add-to-cart, session cart, signup/login/logout, checkout (cash on delivery) with stock checks,
order history, and a full admin panel for products, categories and orders.
