// Add to cart without reloading the page
document.addEventListener("submit", async function (e) {
  const form = e.target.closest(".add-form");
  if (!form) return;
  e.preventDefault();
  const btn = form.querySelector("button");
  btn.disabled = true;
  try {
    const res = await fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: { "X-Requested-With": "XMLHttpRequest" },
    });
    const data = await res.json();
    document.getElementById("cart-count").textContent = data.count;
    const toast = document.getElementById("toast");
    toast.className = "toast " + (data.ok ? "text-bg-success" : "text-bg-danger");
    document.getElementById("toast-body").textContent = data.message;
    bootstrap.Toast.getOrCreateInstance(toast, { delay: 2500 }).show();
  } catch (err) {
    form.submit();
  } finally {
    btn.disabled = false;
  }
});
